userInput = input("input 1-10-: ")

print(type(userInput))

if int(userInput) == 9:
    print(userInput)
else:
    print("Loh?")